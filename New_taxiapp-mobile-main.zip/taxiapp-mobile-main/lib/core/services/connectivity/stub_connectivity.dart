class ConnectivityService {
  Future<bool> get isConnected =>
      throw UnsupportedError('Can not initialize stub client');
}
