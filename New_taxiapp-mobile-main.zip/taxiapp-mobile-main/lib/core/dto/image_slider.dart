class ImageSliderDto {
  List<String> images;
  int initialIndex;

  ImageSliderDto({
    required this.images,
    required this.initialIndex,
  });
}
