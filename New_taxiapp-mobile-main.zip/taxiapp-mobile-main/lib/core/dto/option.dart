class Option {
  final String value;
  final String label;

  const Option({
    required this.value,
    required this.label,
  });
}
