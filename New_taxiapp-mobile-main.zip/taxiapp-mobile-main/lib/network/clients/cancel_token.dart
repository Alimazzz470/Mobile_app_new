import 'package:dio/dio.dart';

// Having a type alias to remove dio import usage everywhere
typedef CancellationToken = CancelToken;
