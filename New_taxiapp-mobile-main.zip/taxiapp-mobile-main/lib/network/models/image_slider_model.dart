class ImageSliderModel {
  List<String> images;
  int initialIndex;

  ImageSliderModel({
    required this.images,
    required this.initialIndex,
  });
}
